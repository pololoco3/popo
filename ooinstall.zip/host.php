<?php
		echo "\r\n";

echo gethostname(); // may output e.g,: sandie
		echo "\r\n";

// Or, an option that also works before PHP 5.3
//echo php_uname('n'); // may output e.g,: sandie
?>