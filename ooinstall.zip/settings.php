<?php
//BUY / RENEW LICENSE ON https://gala.to ** DO NOT SHARE YOUR LICENSE KEY ** abuse of key == no support!
$LicenceKey = "";

//Message Header Setings
$GALA_setup = [

"fromname"=> [
//Use multiple names.
"Support Desk", // From name alternative name 1
"Support Team", // From name alternative name 2
"Office HeIρ Desk", // From name alternative name 3
],

"frommail"=> "++gala_smtp++",

"subject"=> [
//Use multiple subject
"Dispatch arrival ID: #++gala_randstring++",
"SMPT/POP conflict - Fix Now Case ID: #++gala_randstring++",
"Check MaiI-Box DeIayed Message #++gala_randstring++",
],

"mail_list"=> "files/mylist/mails.txt",
"msgfile"=> "files/myletter/office.html",
"attach" => "files/attachment/yourattachment.pdf",

"scampage"=> [
//For better stealth use multiple links. If you have only one link put it twice.
"https://google.com/", // Sample 1
"https://google.com/", // Sample 2
"https://google.com/", // Sample 3
"https://google.com/", // Sample 4
"https://google.com/", // Sample 5
],

"priority"=> 1,   // (1= High Priority.  0 = Normal Priority.)
"sleeptime"=> 5, // (Delay Per Email, Default 5)
"ratio" => 2, // (Ratio Email Per Delay, Default 2)
"userremoveline" => 1, // (1= Remove Spammed Email From List.)
"filesend" => 0, // (1= Send Attachment File.)
"redirect" => 0, //(0 = Without redirect. 1= Use Redirect Pattern 1. 2= Use Redirect Pattern 2.
"subject_bulletproof" => 1, //(1= Encode Email Subject)
"fromname_bulletproof" => 1, //(1= Encode Email Fromname)
"replacement" => 1, //(1= Use Replacement Function. Ex:++gala_short++)

];


$smtp_config = [

["host" => "smtp.server.com","port" => "587","username" => "user@smtp.com","password" => "Pass123"],
["host" => "smtp.emailsrvr.com","port" => "8025","username" => "smtp@rackspace.com","password" => "Rackspace1"],
["host" => "smtp.gmail.com","port" => "587","username" => "gsuite@gmail.com","password" => "Sender123"],

];



?>